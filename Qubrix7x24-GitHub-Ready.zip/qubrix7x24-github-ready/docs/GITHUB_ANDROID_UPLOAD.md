# Upload this project to GitHub from Android

This package is already arranged as a repository. The objective is to place the **contents** of this folder in the root of your private repository `qubrix724/qubrix-deployment`.

## Before starting

- Keep the repository private while development is in progress.
- Download the project ZIP to your Android phone.
- Use Chrome and sign in to the GitHub account that owns the repository.
- Do not publish passwords, tokens, `.env` files, `.dev.vars`, customer records or database backups.

## GitHub website method

1. Open `https://github.com/qubrix724/qubrix-deployment` in Chrome.
2. If the repository is empty, choose **Add file** then **Upload files**. If you do not see it, open the repository's **Code** tab and use the Add file menu.
3. Android browsers may not upload a ZIP as an extracted project. If GitHub shows a file picker, do not upload only the ZIP and assume GitHub will unpack it.
4. Use GitHub Codespaces if the browser upload workflow cannot extract the archive: open the repository, select **Code → Codespaces → Create codespace on main**. In the terminal, use the browser's upload/file feature if available, then unzip the downloaded archive into the repository directory. Commit and push the files.
5. Confirm the repository root visibly contains `package.json`, `index.html`, `src`, `worker`, `schema.sql`, `wrangler.jsonc`, and `docs`.

## What a successful upload looks like

```text
qubrix-deployment/
  docs/
  public/
  src/
  worker/
  .gitignore
  index.html
  package.json
  README.md
  schema.sql
  tsconfig.json
  vite.config.ts
  wrangler.jsonc
```

## Important

The ZIP contains source files, not a deployed website. GitHub stores code; Cloudflare hosts the website/API after you configure the services. Do not paste secret values into GitHub files or screenshots. If the Android UI differs, use GitHub's current Help pages rather than guessing which button to tap.
