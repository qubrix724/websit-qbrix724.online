# Production Readiness Gate

Do not call this application production-ready until every critical item below is evidenced.

## Product and operations
- [ ] Confirm pilot outlet workflow and service catalogue.
- [ ] Confirm who can create, edit, cancel and complete bookings.
- [ ] Confirm bay assignment, staff assignment and quality-check process.
- [ ] Define downtime/manual fallback procedure.
- [ ] Train staff and obtain feedback from a controlled pilot.

## Engineering
- [ ] Replace localStorage demo with authenticated API integration.
- [ ] Complete sign-in, account recovery, session expiry and revocation.
- [ ] Complete role-based access control and server-derived tenant scope.
- [ ] Add schema migrations, validation and idempotency for writes.
- [ ] Add audit logs for financial, customer and permission changes.
- [ ] Add pagination, monitoring, structured logs and error reporting.
- [ ] Add automated unit, integration, end-to-end and cross-tenant tests.
- [ ] Test mobile Chrome, low-bandwidth conditions and supported devices.
- [ ] Test PWA install/update and offline behaviour; define conflict handling.
- [ ] Configure backups and demonstrate a successful restore.
- [ ] Run dependency, secret and security scans; resolve critical/high findings.

## Legal and privacy
- [ ] Privacy notice, terms, cancellation/refund and support contact approved.
- [ ] Data map, retention schedule, processor list and deletion/export process documented.
- [ ] Consent capture and withdrawal tested where applicable.
- [ ] Indian counsel review of applicable DPDP/IT/consumer requirements.
- [ ] CA review of GST, invoice and accounting treatment.
- [ ] IP ownership and open-source licence review completed.

## Release and cost
- [ ] Separate staging and production environments.
- [ ] Production secrets stored only in platform secret manager.
- [ ] Free-tier limits, quotas and billing alerts reviewed.
- [ ] No unintended paid plan, resource or usage-based service enabled.
- [ ] Rollback procedure tested.
- [ ] Pilot owner signs off on acceptance criteria.
