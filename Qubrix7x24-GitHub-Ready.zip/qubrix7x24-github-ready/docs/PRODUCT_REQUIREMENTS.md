# Qubrix7x24 — Product Requirements Document

**Version:** 1.0 · **Date:** 17 November 2026 · **Initial market:** India · **Pilot:** One car-wash outlet

## 1. Product vision

Qubrix7x24 is an operating system for car-wash businesses. It should help an owner run bookings, vehicle check-in, wash-bay allocation, staff workflows, job quality checks, billing, expenses and outlet performance from one mobile-friendly workspace.

The first release is deliberately limited to one outlet. Multi-outlet, corporate fleet, franchise and AI forecasting capabilities are later phases, not launch blockers.

## 2. Target users

- Owner: outlet performance, revenue, expenses, staff and service configuration.
- Manager: bookings, bay allocation, job status and customer issues.
- Front desk: customer/vehicle check-in, booking and invoice preparation.
- Wash staff: assigned jobs, checklists and completion evidence.
- Customer (later): booking, service history, invoice and feedback.

## 3. MVP goals

1. Record a booking against a service and vehicle.
2. Track a vehicle from booked to checked-in, in-progress and completed.
3. Show live wash-bay capacity and job status.
4. Record the service price and payment status (payment gateway integration is later).
5. Show daily job and revenue summaries.
6. Support English and Hindi on mobile screens.
7. Work as an installable PWA on Android Chrome.

## 4. Out of scope for the first pilot

- Automated AI decisions or dynamic pricing.
- Automated number-plate recognition.
- Real payment processing or stored card data.
- Legally certified GST invoicing without CA review.
- Payroll, statutory HR, accounting ledger or tax filing.
- Franchise royalty settlement and multi-country tax.
- Public Android app-store launch.

## 5. Functional requirements

### Bookings
- Create booking with customer, vehicle registration, service and scheduled time.
- Validate required fields and prevent accidental duplicate submissions.
- Permit status updates with actor, timestamp and reason in the connected release.
- Support search by customer and vehicle registration.

### Wash jobs
- Convert a checked-in booking into a job.
- Assign a bay and staff member.
- Track queued, washing, quality-check and completed states.
- Record checklist completion and before/after evidence in a later release.

### Customers and vehicles
- Store only necessary customer and vehicle information.
- Normalize vehicle registration and avoid exposing personal data to unauthorized roles.
- Provide correction, export and deletion workflows subject to applicable legal retention obligations.

### Billing and reports
- Store amounts as integer paise, not floating-point currency.
- Separate subtotal, CGST, SGST and IGST fields.
- Keep invoice numbers immutable and unique per tenant.
- Require accountant/CA validation of tax rules before real invoices are issued.

### Language and accessibility
- English and Hindi UI labels.
- Touch targets suitable for mobile use.
- Clear loading, empty, error and offline states in the connected release.

## 6. Non-functional requirements

- Responsive layout from 320px mobile width upward.
- HTTPS for all deployed traffic.
- Server-side authorization; UI hiding is not authorization.
- Tenant isolation on every tenant-owned record and query.
- Audit logs for sensitive operations.
- Regular backups and tested restore procedure.
- Minimize personal data and define retention periods.

## 7. Success measures for pilot

Measure baseline and pilot performance rather than assuming savings:
- Median time from arrival to job assignment.
- Booking-to-completion time.
- Jobs completed per bay per day.
- Rework/complaint rate.
- Revenue per service and per operating day.
- Front-desk administration minutes per vehicle.
- Customer repeat rate, where lawful consent and reliable measurement exist.

## 8. Roadmap

**Phase 0 — prototype:** browser demo, UI validation and product feedback.

**Phase 1 — single outlet pilot:** authentication, roles, tenant/outlet setup, server-backed bookings/jobs, bay board, checklists, invoices/payment status, audit logs, backup/restore and privacy workflows.

**Phase 2 — multi-outlet:** consolidated reporting, inventory, staff incentives, customer loyalty and corporate fleet accounts.

**Phase 3 — intelligence:** demand forecasting, suggested staffing, capacity planning and pricing recommendations. Human approval remains required for material business decisions.

## 9. Acceptance criteria for public pilot

- No critical/high security findings remain unresolved.
- Cross-tenant access tests pass.
- Backup restore is demonstrated.
- Role-based permissions are tested for every endpoint.
- Privacy notice, terms, consent and support contact are published.
- Invoice and GST logic is reviewed by an Indian CA.
- At least one outlet completes a full day of test transactions with reconciled totals.
