# Qubrix7x24 — ROI Measurement Model

Do not promise savings or revenue uplift as guaranteed outcomes. Record baseline data and compare it with measured pilot results.

## Time released

`Monthly hours released = (baseline admin minutes − measured admin minutes) × vehicles per day × operating days ÷ 60`

Illustrative example only: if admin work falls from 60 to 5 minutes per vehicle, 10 vehicles/day are processed, and the outlet operates 26 days/month, the calculated time released is 238.3 hours/month. This example is a scenario, not a product claim or expected result.

## Labour value

`Estimated labour value = monthly hours released × loaded hourly labour cost`

Use the actual wage and overhead cost. Time released is not automatically a cash saving unless staffing, overtime or capacity changes convert it into value.

## Incremental contribution

`Incremental monthly contribution = additional completed jobs/day × contribution margin/job × operating days`

Use contribution margin after variable costs, not gross selling price. Do not double-count jobs already included in baseline demand.

## Payback

`Payback months = one-time implementation cost ÷ monthly net benefit`

If monthly net benefit is zero or negative, payback is not achieved. Include hosting, support, training, payment fees, devices, taxes and maintenance in the cost model.

## Pilot measurement

Capture at least two weeks of baseline data where practical, then compare equivalent operating days during the pilot. Record seasonality, weather, promotions, staffing and service-mix changes that may affect results.
