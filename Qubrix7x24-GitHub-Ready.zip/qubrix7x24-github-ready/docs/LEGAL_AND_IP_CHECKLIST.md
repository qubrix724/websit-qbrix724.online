# India Launch — Legal, IP and Commercial Checklist

This is a planning checklist only. It is not a legal opinion, tax opinion or guarantee of compliance.

## Brand and intellectual property

- Search the proposed Qubrix/Qubrix7x24 marks for conflicting earlier marks before public brand investment.
- Obtain advice on appropriate trademark classes and file through the official Indian IP process if cleared.
- Confirm ownership of source code, UI, database schema, product documents, logo and commissioned creative work.
- Use written developer/designer agreements covering assignment of deliverables, confidentiality, pre-existing materials, open-source components, warranties and handover.
- Keep a software bill of materials and comply with each dependency's licence.
- Do not claim that a name, logo or domain is legally available until searches and registrations are checked.

## Company and commercial structure

- Decide whether to operate as an individual proprietorship, partnership, LLP or company with professional advice.
- Confirm invoicing, accounting, GST registration and tax treatment with a Chartered Accountant based on turnover, supply type, state and current law.
- Prepare customer terms, cancellation/refund rules, service disclaimers and complaint handling.
- If selling to franchises, prepare a franchise agreement covering brand licence, territory, fees, standards, audit, data, IP, termination and dispute resolution.
- For corporate/fleet customers, define service levels, pricing, credit, vehicle authorization, data sharing and liability.

## Privacy and consumer obligations

- Publish privacy notice and terms before collecting real customer data.
- Obtain and record consent where legally required; marketing consent should be separate from service fulfilment.
- Provide a contact for privacy requests and grievances.
- Review the DPDP Act, applicable Rules and commencement notifications as they evolve.
- Review Consumer Protection Act/e-commerce applicability and online booking disclosures where relevant.

## GST and invoices

- Have a CA determine applicable service classification, rate, place-of-supply, registration and invoice requirements.
- Validate CGST/SGST vs IGST logic for the actual transaction and registration context.
- Do not issue tax invoices from this prototype; its sample dashboard is not a tax engine.
- Retain required records for statutory periods and support correction/credit-note processes where applicable.

## Employment and outlet operations

- Review applicable state labour, wage, safety, contractor and workplace requirements.
- Document staff responsibilities, safety training, chemical handling and equipment maintenance.
- Define customer vehicle custody, pre-existing damage documentation and complaint process.

## Open-source and third-party services

- Review each library licence and Cloudflare/Firebase/other service terms.
- Keep attribution and notices where required.
- Do not use unofficial WhatsApp automation or scrape customer data from third-party platforms.
- Review cross-border data processing and vendor contracts before using global services.
