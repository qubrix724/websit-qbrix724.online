# Cloudflare Deployment Guide

This guide describes the intended deployment path. It does not mean a Cloudflare account, database or live deployment has already been created.

## A. Frontend build

On a computer or GitHub Codespace with Node.js 20+:

```bash
npm install
npm run typecheck
npm run build
```

Deploy the static `dist/` directory using Cloudflare Pages or the supported Workers static-assets configuration chosen for the project. Keep the frontend and API origins explicit and configure CORS to the exact deployed frontend origin.

## B. Create D1

1. In Cloudflare dashboard, open Workers & Pages → D1.
2. Create a database named `qubrix7x24-db`.
3. Copy its database ID.
4. Replace `REPLACE_WITH_YOUR_D1_DATABASE_ID` in `wrangler.jsonc` with that ID.
5. Apply `schema.sql` to the database using the dashboard or Wrangler migration workflow.
6. Keep production and staging databases separate.

CLI example (after installing dependencies and authenticating Wrangler):

```bash
npx wrangler d1 execute qubrix7x24-db --remote --file=./schema.sql
```

Check current Wrangler syntax and Cloudflare product limits before executing. Do not run schema changes against production without a backup and review.

## C. Configure Worker secrets

Set secrets using Wrangler; never put real secrets in `wrangler.jsonc` or source code.

```bash
npx wrangler secret put ADMIN_API_TOKEN
```

Set `ALLOWED_ORIGIN` as a Worker variable to the exact HTTPS website origin. The current starter's single bearer-token guard is for controlled technical testing only. It is not a complete user authentication or role-based access system and must not be exposed as a public customer API.

## D. Deploy Worker

```bash
npx wrangler deploy
```

Test only the public health endpoint first:

```text
GET https://YOUR-WORKER-DOMAIN/api/health
```

Protected booking endpoints require the configured bearer token and a correctly initialized D1 schema. Do not put the token in browser JavaScript or public environment variables.

## E. Connect frontend to API

The current React screens use browser-local demo data. Before connecting them to the Worker, implement real sign-in, session management, per-user roles, server-derived tenant/outlet scope, CSRF protections where applicable, input validation, audit events and error handling. The current API starter is not sufficient for a live multi-user system.

## F. Free-tier cost controls

- Start with free tiers and no paid add-ons.
- Do not enable pay-as-you-go or add a payment method merely to finish setup.
- Set usage alerts and review billing/usage after each pilot test.
- Re-check current Cloudflare limits and terms; quotas and plan features can change.
- Keep large media uploads out of the database; evaluate private object storage only when needed.

## Rollback

Keep the previous known-good deployment and a database backup before schema changes. Roll back code independently from database changes; use additive migrations and a documented restore plan. Test restore before storing live customer data.
