# Security, Privacy and Data Protection Requirements

This is an engineering checklist, not legal advice or a compliance certificate.

## Data minimization

Collect only information necessary to book and deliver a wash service. Avoid collecting Aadhaar, precise location, payment card data, identity documents or sensitive personal information unless a separately assessed legal and operational need exists.

## Authentication and access control

Before live use:
- Use a reputable identity/session design with secure password hashing if passwords are used (Argon2id or an appropriately configured alternative).
- Enforce MFA for owner/admin accounts where feasible.
- Use short-lived access sessions, secure refresh rotation, revocation and secure cookie settings where cookie sessions are selected.
- Enforce role permissions on the server for every route.
- Do not treat hidden buttons or frontend route guards as security.
- Protect administrative actions with re-authentication where appropriate.

## Application security

- HTTPS only; secure headers and a restrictive Content Security Policy.
- Validate all inputs server-side with explicit schemas and length limits.
- Use parameterized SQL statements.
- Rate-limit authentication and write endpoints.
- Add CSRF protection when cookie-based authentication is used.
- Avoid leaking stack traces, tokens or personal information in logs.
- Rotate secrets and restrict access to production accounts.
- Review dependencies and remove unused packages.
- Conduct threat modelling and independent security testing before public launch.

## Tenant security

Derive tenant membership from the authenticated identity on the server. Never trust a tenant ID supplied by the browser. Include tenant constraints in every query and test attempts to access another tenant's records. Restrict object-storage paths and signed URLs to authorized tenant/outlet resources.

## Privacy operations

Prepare a clear privacy notice describing data collected, purposes, legal basis/consent where applicable, processors, retention, security practices, user rights and contact/grievance channel. Provide processes for correction, access, export, deletion and withdrawal of consent where applicable. Keep statutory/business records only as long as required and document exceptions.

## India legal review

Have qualified Indian counsel review applicability and commencement of the Digital Personal Data Protection Act, 2023 and Rules/notifications, the Information Technology Act and applicable rules, consumer-protection requirements, GST/invoicing obligations, employment obligations and any sector-specific rules. Do not assume every provision has the same effective date. Re-check official Gazette notifications at launch.

## Incident response

Document who investigates incidents, how credentials are revoked, how affected systems are isolated, how evidence is preserved, who assesses notification duties and how recovery is verified. Maintain an incident contact list and conduct a tabletop exercise before the pilot.

## Current prototype warning

The frontend stores demo bookings in browser localStorage. The Worker starter uses one shared bearer secret and does not implement user identity, role checks, tenant authorization or audit logging. This is not appropriate for real customer data.
