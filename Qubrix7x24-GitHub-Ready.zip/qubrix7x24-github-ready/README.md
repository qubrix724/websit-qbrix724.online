# Qubrix7x24 — Car Wash Business Operating System

A mobile-first, bilingual (English/Hindi) PWA starter for an India-first car wash outlet. This repository contains a working **browser demo** plus a Cloudflare Workers + D1 API/schema starter.

> **Important status:** This is a pilot prototype, not a production-ready SaaS. The dashboard currently uses sample data and browser `localStorage`. The Worker API is a starter and is not yet wired to the React screens. Do not enter real customer data or use it for live payments, GST invoices, employee records, or franchise operations until authentication, authorization, tenant isolation, privacy controls, backups, and operational testing are completed.

## What is included

- Responsive owner/operator dashboard
- English/Hindi interface switch
- Light/dark appearance switch
- Sample revenue, bookings and wash-bay overview
- Create bookings and update their status in the browser demo
- PWA manifest and installable-app configuration
- Cloudflare Worker API starter (`/api/health`, protected booking read/create routes)
- D1 schema for tenants, outlets, customers, vehicles, services, bays, bookings, jobs, invoices, expenses and audit logs
- Setup, deployment, security, legal and pilot documents in `docs/`

## Technology

- React + TypeScript + Vite
- PWA plugin for Vite
- Cloudflare Workers + D1 (backend starter)
- CSS responsive layout; no paid UI component library

## Run locally

Requires Node.js 20 or later and npm.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (normally `http://localhost:5173`).

Create a production build:

```bash
npm run typecheck
npm run build
```

The output is written to `dist/`.

## GitHub upload

1. Create or open the private repository `qubrix724/qubrix-deployment`.
2. Upload the contents of this project ZIP (not the ZIP file itself) to the repository root, or use GitHub Codespaces and extract the ZIP there.
3. Confirm that `package.json`, `src/`, `worker/`, `schema.sql`, `wrangler.jsonc`, and `docs/` are visible at the root.
4. Do not upload `.dev.vars`, `.env` files, access tokens, passwords, customer data or production database exports.

See `docs/GITHUB_ANDROID_UPLOAD.md` for the Android browser workflow.

## Cloudflare setup

Read `docs/CLOUDFLARE_DEPLOYMENT.md`. You must create your own Cloudflare account, D1 database and secret values. Replace the placeholder database ID in `wrangler.jsonc`; never commit secrets. Cloudflare free-tier limits and product terms can change—verify them in the Cloudflare dashboard before deployment.

## Demo data

The current demo stores bookings in the browser's local storage. Data is specific to the browser/device and is not a secure backup. Clearing browser data may delete it. This is intentional for a no-cost prototype and must be replaced by authenticated server-side storage before a real pilot.

## Before a real pilot

See `docs/PRODUCTION_READINESS.md` and `docs/SECURITY_AND_PRIVACY.md`. At minimum: implement verified authentication, server-side role checks, tenant isolation, secure sessions, rate limiting, audit trails, data export/deletion, backups/restore tests, monitoring, consent and privacy notices, and independent security review.

## License

No open-source license has been selected. Unless a license is added, the source remains proprietary and all rights are reserved by the rights holder. Do not add an MIT/Apache/GPL license unless the project owner has consciously chosen that distribution model.
