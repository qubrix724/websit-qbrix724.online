interface Env {
  DB: D1Database;
  ADMIN_API_TOKEN: string;
  ALLOWED_ORIGIN?: string;
  APP_ENV?: string;
}

const json = (data: unknown, status = 200, headers: HeadersInit = {}) =>
  new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json; charset=utf-8', ...headers } });

function cors(request: Request, env: Env): Headers {
  const origin = request.headers.get('Origin') || '';
  const allowed = env.ALLOWED_ORIGIN || '';
  const headers = new Headers({ 'Vary': 'Origin', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type,Authorization' });
  if (allowed && origin === allowed) headers.set('Access-Control-Allow-Origin', origin);
  return headers;
}

function authorized(request: Request, env: Env): boolean {
  if (!env.ADMIN_API_TOKEN) return false;
  return request.headers.get('Authorization') === `Bearer ${env.ADMIN_API_TOKEN}`;
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const headers = cors(request, env);
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers });
    const url = new URL(request.url);

    if (url.pathname === '/api/health' && request.method === 'GET') {
      return json({ ok: true, service: 'Qubrix7x24 API', environment: env.APP_ENV || 'development' }, 200, headers);
    }

    if (!authorized(request, env)) return json({ error: 'Unauthorized' }, 401, headers);

    if (url.pathname === '/api/bookings' && request.method === 'GET') {
      const tenantId = url.searchParams.get('tenant_id');
      if (!tenantId) return json({ error: 'tenant_id is required' }, 400, headers);
      const result = await env.DB.prepare(
        'SELECT id, scheduled_at, status, notes, customer_id, vehicle_id, service_id, outlet_id FROM bookings WHERE tenant_id = ? ORDER BY scheduled_at DESC LIMIT 100'
      ).bind(tenantId).all();
      return json({ data: result.results }, 200, headers);
    }

    if (url.pathname === '/api/bookings' && request.method === 'POST') {
      let body: Record<string, unknown>;
      try { body = await request.json() as Record<string, unknown>; }
      catch { return json({ error: 'Invalid JSON body' }, 400, headers); }
      const required = ['id', 'tenant_id', 'outlet_id', 'scheduled_at'];
      if (required.some((key) => typeof body[key] !== 'string' || !(body[key] as string).trim())) {
        return json({ error: 'id, tenant_id, outlet_id and scheduled_at are required strings' }, 400, headers);
      }
      await env.DB.prepare(
        `INSERT INTO bookings (id, tenant_id, outlet_id, scheduled_at, status, notes, customer_id, vehicle_id, service_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).bind(body.id, body.tenant_id, body.outlet_id, body.scheduled_at, body.status || 'booked', body.notes || null,
        body.customer_id || null, body.vehicle_id || null, body.service_id || null).run();
      return json({ ok: true, id: body.id }, 201, headers);
    }

    return json({ error: 'Not found' }, 404, headers);
  }
};
